Chou, Cheng, and Vineet Kumar. ``Can Willingness to Pay be Identified without
Price Variation? What Usage Tracking Data Can (and Cannot) Tell Us''
Dec 16, 2022
For questions, please contact the authors:
Cheng Chou <cheng.chou@icloud.com>
Vineet Kumar <vineet.kumar@yale.edu>
-----------------------------------------------------------------------------

The shared data and code files are to replicate the results in Section 6
Empirical Application: Music Streaming Service. The data and code are in R
format.

Note: Parameters and Standard Errors are stochastic due to EM algorithm and use of bootstrap. Hence, they are likely to differ slightly from the numbers reported in the paper. However, this variation does not impact the economic quantities (WTP, elasticities etc.).

# Data #
- The data is saved in "data.rds". Use `readRDS` to read the data. "data.rds"
contains a list named `l`, which has two elements---`dsub` and `duse`. `dsub`
contains data about consumers subscription choice. `duse` contains data about
consumer daily usage of the product. The data have the following variables
* `msno`: unique ID of a consumer
* `Month`: month id
* `S`: dummy variable of subscription decision. `S = 1` means subscribe, and
  `S = 0` means otherwise.
* `Age`: age
* `price`: monthly price of the subscription
* `Tenure`: consumer tenure in weeks
* `sdate`: date of the observation (irrelevant for subscription data, but
  useful for usage estimation)
* `sregdate`: date of registration for each consumer
* `Female`: dummy variable for being female
* `RH2M`: relative humidity
* `PRECTOT`: precipitation
* `Holiday`: holiday dummy
* `WEEKEND`: weekend dummy
* `Q`: listening hours (day)
  
# Code #
- `estimation.R` is the main program to summarize the data, run estimation, and
plot various graphs.
- `plot_theme.R` will be called by `estimation.R`, and it defines a few
functions for `ggplot` theme.
