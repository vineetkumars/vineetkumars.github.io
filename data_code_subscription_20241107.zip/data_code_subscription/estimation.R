rm(list=ls())
options(warn=-1)
library("dplyr"); library("lubridate"); library("purrr"); library("AER")
library("tidyr"); library("kableExtra"); library("ggplot2"); library("truncnorm")
library("Formula"); library("flexmix"); library("boot")
library("progress")
l <- readRDS("data.rds")
source("plot_theme.R")
dsub2 <- l$dsub
duse2 <- l$duse

set.seed(1)

# Data summary ------------------------------------------------------------
sum_use <- duse2 %>% group_by(msno) %>% mutate(
  # Have ever canceled
  cancel = as.integer(any(S == 0))
) %>% ungroup()
sum_sub <- dsub2 %>% group_by(msno) %>% mutate(
  # Have ever canceled
  cancel = as.integer(any(S == 0))
) %>% ungroup()
# Usage
range(sum_use$sdate)
sum_use %>%
  summarise(
    Group = "All",
    Usage = mean(Q, na.rm = TRUE),
    Usage_sd = sd(Q, na.rm = TRUE),
    PRECTOT_mean = mean(PRECTOT),
    PRECTOT_sd = sd(PRECTOT),
    Hum = mean(RH2M),
    Hum_sd = sd(RH2M),
  ) %>% as.data.frame()
sum_use %>% group_by(Group = cancel) %>% 
  summarise(
    Usage = mean(Q, na.rm = TRUE),
    Usage_sd = sd(Q, na.rm = TRUE),
    PRECTOT_mean = mean(PRECTOT),
    PRECTOT_sd = sd(PRECTOT),
    Hum = mean(RH2M),
    Hum_sd = sd(RH2M),
    .groups = "drop"
  ) %>% as.data.frame()
sum_sub %>%
  summarise(
    Group = "All",
    Age_mean = mean(Age),
    Age_sd = sd(Age),
    Female = mean(Female) * 100,
  ) %>% as.data.frame()
sum_sub %>% group_by(Group = cancel) %>% 
  summarise(
    Age_mean = mean(Age),
    Age_sd = sd(Age),
    Female = mean(Female),
    .groups = "drop"
  ) %>% as.data.frame()
sum_sub %>% group_by(Month) %>% summarise(meanS = mean(S)) %>% as.data.frame()
length(unique(sum_sub$msno)) # number of unique consumers
length(unique(filter(sum_sub, cancel == 0)$msno)) # number of consumers who never cancelled
length(unique(filter(sum_sub, cancel == 1)$msno)) # number of consumers who ever cancelled

always1 <- dsub2 %>% select(msno, S) %>% group_by(msno) %>% 
  summarize(Always = 
              factor(min(S), 
                     levels = c(0, 1), labels = c("Ever Cancelled", "Never Cancelled")))
qmonth <- duse2 %>% select(msno, Month, Q) %>% group_by(msno, Month) %>% 
  summarise(Q = sum(Q), .groups = "drop") %>% 
  left_join(always1, by = "msno")
gg1 <- ggplot(data=qmonth, aes(x=Q, group=Always, fill=Always)) +
  geom_density(adjust=1.5) +
  facet_wrap(~Always) +
  theme_Publication(base_size = 24) +
  labs(x = "Monthly Usage (Streaming Hours)") +
  theme(
    legend.position="none",
    panel.spacing = unit(0.1, "lines"),
    axis.ticks.x=element_blank()
  )
# Uncomment to save plot
# ggpubr::ggexport(gg1, filename = "densityMonthUsage.png", width = 900)
qmonth %>% group_by(Always) %>% 
  summarise(q_mean = mean(Q, na.rm = TRUE), q_sd = sd(Q, na.rm = TRUE)) %>% as.data.frame
# mean and sd of usage among all consumers
mean(qmonth$Q, na.rm = TRUE); sd(qmonth$Q, na.rm = TRUE)
tenure1 <- dsub2 %>% select(msno, Month, Tenure)
qtenure <- duse2 %>% select(msno, Month, Q) %>% group_by(msno, Month) %>% 
  summarise(Q = sum(Q), .groups = "drop") %>% 
  left_join(tenure1, by = c("msno", "Month"))
gg2 <- ggplot(qtenure, aes(x = Tenure, y = Q)) + geom_point(colour = "grey") +
  stat_smooth(method = "loess") +
  labs(x = "Customer Tenure (Weeks)", y = "Monthly Usage (Streaming Hours)") +
  theme_Publication(base_size = 16)
# Uncomment to save plot
# ggpubr::ggexport(gg2, filename = "usageXtenure.png", height = 300, width = 500)
use_churn <- duse2 %>% group_by(msno, Month) %>% 
  summarise(Q = sum(Q), S = min(S)) %>% 
  group_by(msno) %>% mutate(S_ever = min(S), S_lead = lead(S, order_by = Month)) %>% 
  ungroup() %>% 
  filter(S_ever == 0) %>% 
  drop_na() %>% 
  mutate(mbc = factor(
    ifelse(S - S_lead == 1, 1, 0), levels = c(0, 1), 
    labels = c("Other Months with Subscription", "The Month before Cancellation")
  ))
gg3 <- ggplot(use_churn, aes(x = mbc, y = Q)) + geom_boxplot()  +
  labs(y = "Monthly Usage (Streaming Hours)") + labs(x = "") +
  theme_Publication(base_size = 24)
# Uncomment to save plot
# ggpubr::ggexport(gg3, filename = "usageBeforeCancellation.png", width = 900)
rh <- ggplot(filter(duse2), aes(x = RH2M, y = Q)) + geom_point(color = "grey") +
  stat_smooth(method = "lm", se = FALSE) + 
  labs(x = "Relative Humidity", y = "Daily Usage (Streaming Hours)") +
  theme_Publication(base_size = 16)
# Uncomment to save plot
# ggpubr::ggexport(rh, filename = "humidityUsage.png")

# Estimation starts here --------------------------------------------------

# function for estimating usage equation. The slopes (e.g. the coefficients of
# holiday and weekedn) can be heterogeneous.
em_trnormal_empirical_type_slopes <- function(
  formula, id, data, K, niter.em = 500, n.init = 10
) {
  # id is supplied to capture repeated observations.
  mf <- model.frame(formula, data) # mf has removed NA rows.
  y <- model.response(mf, "numeric")
  x <- model.matrix(formula, data, rhs = 1)
  x1 <- model.matrix(formula, data, rhs = 2)[, -1, drop = FALSE] # X whose slopes are type specific (excluding intercept)
  nm1 <- c("(Intercept)", colnames(x1))
  x <- x[, c(nm1, setdiff(colnames(x), nm1))] # rearrange the order of x columns if needed
  dx1 <- ncol(x1)
  dx2 <- ncol(x) - dx1 - 1
  x2 <- x[, -c(1:(1 + dx1)), drop = FALSE]
  idvec <- tibble(!!id := unique(pull(data, id)))
  nid <- data %>% group_by_at(id) %>% summarise(nid = n(), .groups = "drop") # group_by doesn't preserve the original order of id. cause problem
  nid <- left_join(idvec, nid, by = id)
  n <- nrow(nid)
  N <- nrow(data)
  pname <- c(
    paste0("cnst_", 1 : K), paste0("r_", 1 : K),
    unlist(map(1:K, ~ paste0(colnames(x1), "_", .x))),
    colnames(x2)
  )
  
  # LAYOUT OF PARAMETERS
  # Type  1    2    ... K
  #       ---------------
  #       mu_1 mu_2 ... mu_K
  #       r_1  r_2  ... r_K
  #       b_1  b_2  ... b_K   (type specific slopes)
  #       common slopes
  
  # pstr function
  pstrfun <- function(para, prior) {
    para_type <- head(para, (2 + dx1) * K)
    cnst <- para_type[1 : K]
    r <- para_type[(K+1) : (K + K)]
    slope_type <- matrix(tail(para_type, - (K + K)), nr = dx1, nc = K)
    slope_cmn <- tail(para, - (2 + dx1) * K)
    ll <- matrix(nr = n, nc = K) # likelihood matrix. ll[i,k] = pi_{k} * f(z | type of i = k)
    d <- matrix(nr = N, nc = K)
    LL <- matrix(nr = N, nc = K)
    for (k in 1 : K) {
      slope <- c(slope_type[,k], slope_cmn)
      d[,k] <- y / r[k] - drop(x %*% c(0, slope)) - cnst[k]
      ll.k <- dtruncnorm(d[,k], a = 0) / r[k] # likelihood of being type k
      # REMARK: ll[,1] and ll[,2] can both be zero even when ll.k is nonzero, because of the product of many small probabilities.
      ll[,k] <- prior[k] * sapply(split(ll.k, data[[id]]), prod)
      LL[,k] <- prior[k] * ll.k
    }
    loglike <- sum(log(rowSums(LL))) # log likelihood of incomplete data
    BIC <- length(c(unlist(para), prior)) * log(N) - 2 * loglike
    # posterior prob of belonging to each class. The k-th column is for class k
    pstr <- t(apply(ll, 1, prop.table))
    bad <- which(apply(pstr, 1, function(x) any(is.na(x))))
    if (length(bad) > 0) {
      warning("Bad posterior found. Posterior probs for all classes are zero.")
      pstr <- NULL
    }
    list(loglike = loglike, BIC = BIC, pstr = pstr)
  }
  pstr_tib <- function(pstr) {
    if (is.null(colnames(pstr))) {
      colnames(pstr) <- paste0("comp", 1:K)
    }
    pstr_tb <- as_tibble(pstr)
    pstr_tb[id] <- nid[[id]]
    as.matrix(data %>% select(all_of(id)) %>% left_join(pstr_tb, by = id) %>% select(-all_of(id)))
  }
  
  fit <- function(pstr, p0 = NULL) {
    # M-step use classification
    pstr2 <- pstr_tib(pstr)
    Cls <- apply(pstr2, 1, which.max)
    # If one component received too few observations (<10), break and assign big loglike
    if(length(table(Cls)) < K | min(table(Cls)) < 10) {
      warning("One or more components do not have enough observations. Maybe K is too large.")
      return(Inf)
    }
    x1_pad <- (model.matrix(~ factor(Cls) - 1) %x% matrix(1, nr = 1, nc = ncol(x1))) *
      (matrix(1, nr = 1, nc = K) %x% x1)
    xCls <- cbind(model.matrix(~ factor(Cls) - 1), x1_pad, x2)
    lfun <- function(r, refit = FALSE) {
      # para = c(r1, ..., rK)
      if (is.null(r)) return(Inf)
      slope <- tail(lm.fit(xCls, y / r[Cls])$coefficients, dx2 + dx1 * K)
      e <- y / r[Cls] - xCls[,-(1:K)] %*% slope
      cnst <- c()
      for (k in 1 : K) {
        cnst[k] <- min(e[Cls == k])
      }
      s <- c()
      for (k in 1 : K) {
        s[k] <- - sum(
          log(dtruncnorm(e[Cls == k] - cnst[k], a  = 0)/r[k])
        )
      }
      if (refit) {
        p <- c(cnst, r, slope)
        names(p) <- pname
        return(p)
      } else {
        return(sum(s))
      }
    }
    # form initial guess. The optim depends on the initial guess. Try multiple ones
    if (is.null(p0) | lfun(p0) == Inf) {
      l_init <- Inf
      while (l_init == Inf) {
        p0 <- runif(K)
        l_init <- lfun(p0)
      }
      o <- optim(p0, lfun)
      # o <- optim(p0, lfun, lower = rep(0.01, K), upper = rep(0.99, K))
      p <- o$par
    } else {
      p <- optim(p0, lfun)$par
    }
    p <- lfun(p, refit = TRUE)
    p
  }
  
  # EM: iterate "fit" and "pstrfun"---THIS DOES NOT DEPEND ON THE PARTICULAR MODEL.
  # CHECK
  para_matrix <- function(para_new) {
    cnst <- matrix(head(para_new, K) + 2 * dnorm(0), nc = K) # first K is constant term. 2 * dnorm(0) is because we have normalized the error have mean 0 in DGP.
    r <- matrix(tail(head(para_new, 2 * K), K), nc = K) # second K is r term; the rest is slope that is common across types
    slope_htr <- matrix(head(tail(para_new, - (2 * K)), - dx2), nc = K)
    slope_cmn <- matrix(rep(tail(para_new, dx2), K), nc = K)
    # odr_intercept <- order(unlist(cnst)) # the difference in cnst is small.
    odr_intercept <- order(unlist(r))
    para.mat <- rbind(cnst, r, slope_htr, slope_cmn)[,odr_intercept]
    dimnames(para.mat) <- list(c("cnst", "r", colnames(x1), colnames(x2)), paste0("Comp.", 1 : K))
    para.mat
  }
  em <- function(para_old, prior_old, niter.em) {
    # para_old <- para.init; prior_old <- prior.init
    loglike_old <- 0
    tol <- 1e-2
    for (i in 1 : niter.em) {
      # update parameters
      # E: find posterior of class for each observation
      pstr1 <- pstrfun(para = para_old, prior = prior_old)
      pstr <- pstr1$pstr
      loglike_new <- pstr1$loglike
      BIC_new <- pstr1$BIC
      # M: find optimizer
      # M1: update prior
      prior_new <- colMeans(pstr)
      # M2: update parameters estimates
      para_new <- fit(pstr, p0 = para_old[c(K+1):(2*K)])
      # para_new <- fit(pstr, p0 = NULL)
      para_df <- abs(loglike_new - loglike_old)
      if (setequal(para_new, Inf)) stop("Assigned K is too large.")
      if (para_df < tol) {
        cat("log likelihood difference ", para_df, "\n")
        break
      } else {
        cat("log likelihood difference ", para_df, "\n")
        para_old <- para_new
        prior_old <- prior_new
        loglike_old <- loglike_new
      }
    }
    # Relabel based on the intercept
    cnst <- matrix(head(para_new, K) + 2 * dnorm(0), nc = K) # first K is constant term. 2 * dnorm(0) is because we have normalized the error have mean 0 in DGP.
    r <- matrix(tail(head(para_new, 2 * K), K), nc = K) # second K is r term; the rest is slope that is common across types
    slope_htr <- matrix(head(tail(para_new, - (2 * K)), - dx2), nc = K)
    slope_cmn <- matrix(rep(tail(para_new, dx2), K), nc = K)
    odr_intercept <- order(unlist(cnst))
    para.mat <- rbind(cnst, r, slope_htr, slope_cmn)[,odr_intercept]
    dimnames(para.mat) <- list(c("cnst", "r", colnames(x1), colnames(x2)), paste0("Comp.", 1 : K))
    rownames(pstr) <- nid[[id]]
    list(
      para = para.mat,
      para.list = para_new,
      prior = prior_new,
      posterior = pstr,
      logl = loglike_new,
      BIC = BIC_new
    )
  }
  
  # Initialization using Gaussian mixture of linear regression model
  lhs <- all.vars(attr(formula, "lhs")[[1]])
  rhs <- sapply(attr(formula, "rhs"), all.vars)
  F1 <- as.formula(paste(lhs, "~", paste0(rhs[[2]], collapse = "+"), "|", id))
  F2 <- as.formula(paste("~", paste(setdiff(rhs[[1]], rhs[[2]]), collapse = "+")))
  fmix <- flexmix(F1, model = FLXMRglmfix(Q ~ ., fixed = F2), data = data, k = K)
  # fmix_fit <- refit(fmix)
  # summary(fmix_fit)
  post2 <- function(pos) {
    colnames(pos) <- paste0("comp", 1:ncol(pos))
    bind_cols(select(data, id), pos) %>% unique %>% select(-id) %>% as.matrix
  }
  pstr_long <- posterior(fmix)
  pstr_init <- post2(pstr_long)
  prior_init <- fmix@prior
  para_init <- fit(pstr = pstr_init, p0 = NULL)
  pstr_init2 <- pstrfun(para = para_init, prior = prior_init) # need to fix BIC problem.
  
  # Simulation shows em() function step does not update the estimates if we used
  # the posterior probabilities from Gaussian mixture regression model (flexmix
  # step)
  # em1 <- em(para_old = para_init, prior_old = prior_init, niter.em = 50)
  return(
    list(
      par = para_matrix(para_init), prior = prior_init, BIC = pstr_init2$BIC, 
      pstr = pstr_init, pstr_long = pstr_long
    )
  )
}

# Usage equation
# Determine the number of types according to BIC
data_small <- duse2 %>% left_join(
    unique(select(dsub2, msno, Age, Female)),
    by = "msno"
  ) %>% filter(! is.na(Q), Q > 0) %>% 
    select(msno, Q, RH2M, PRECTOT, Holiday, WEEKEND, Age, Female)
# Uncomment to try different k = 2, 3, 4
# 2 types is the best choice according to BIC. When k = 4, some components have
# too few observations and the routine might fail to converge.
# Let K = 2 in the rest of estimation.
# use_fit <- list()
# for (k in 2 : 4) {
#   em1 <- em_trnormal_empirical_type_slopes(
#     Formula(Q ~ Holiday + WEEKEND + Age + Female + RH2M + PRECTOT | Holiday + WEEKEND),
#     data = data_small,
#     id = "msno", K = k
#   )
#   use_fit[[k-1]] <- em1
# }
# map(1:2, ~ use_fit[[.x]]$BIC)

# a wrap of estimator for bootstrap
estimate_leisure <- function(users) {
  users <- tibble(msno = users, msno2 = seq_along(users))
  em1 <- em_trnormal_empirical_type_slopes(
    Formula(Q ~ Holiday + WEEKEND + Age + Female + RH2M + PRECTOT | Holiday + WEEKEND),
    data = data_small %>% left_join(users, by = "msno") %>% drop_na,
    id = "msno2", K = 2
  )
  em1$par
}
em1 <- em_trnormal_empirical_type_slopes(
  Formula(Q ~ Holiday + WEEKEND + Age + Female + RH2M + PRECTOT | Holiday + WEEKEND),
  data = data_small,
  id = "msno", K = 2
)
# Uncomment to do bootstrap
boot <- list()
B <- 5 # 5 is for illustation; 200 was used in actual estimation
B <- 200
pb <- progress_bar$new(total = B)
for (b in 1 : B) {
  pb$tick()
  users <- sample(
    unique(pull(data_small, msno)),
    replace = TRUE,
    300
  )
  boot[[b]] <- as.vector(estimate_leisure(users))
}
se_usage <- apply(
  matrix(unlist(boot), nr = length(boot[[1]]), nc = 200),
  1,
  sd
)
se_usage <- matrix(se_usage, nc = 2)
tvalue <- em1$par / se_usage
dimnames(tvalue) <- list(rownames(em1$par), colnames(em1$par))
dimnames(se_usage) <- list(rownames(em1$par), colnames(em1$par))
round(em1$par, 4)
round(se_usage, 4)
# We found Age and Female are insignificant.

# Drop female and age for further analysis
estimate_leisure2 <- function(users) {
  users <- tibble(msno = users, msno2 = seq_along(users))
  # Estimate usage equation
  em2 <- em_trnormal_empirical_type_slopes(
    Formula(Q ~ Holiday + WEEKEND + RH2M + PRECTOT | Holiday + WEEKEND),
    data = data_small %>% left_join(users, by = "msno") %>% drop_na,
    id = "msno2", K = 2
  )
  # Estimates of mu
  mu_tib <- tibble(
    msno = unique(data_small$msno),
    mu_hat = drop(em2$pstr %*% em2$par["cnst", ])
  )
  # Estimate the expected monthly leisure
  duse2 <- duse2 %>% left_join(users, by = "msno")
  dsub2 <- dsub2 %>% left_join(users, by = "msno")
  # posterior matrix---same dimension as the raw useage data (including days without usage or usage = 0)
  pstr_mat <- duse2 %>% select(msno) %>% left_join(
    as_tibble(em2$pstr) %>% mutate(msno = unique(data_small$msno)),
    by = "msno"
  ) %>% select(-msno) %>% as.matrix()
  form1 <- formula(Q ~ Holiday + WEEKEND + RH2M + PRECTOT)
  x.design <- model.matrix(update(form1, NULL ~ .), duse2)
  L <- rowSums((x.design %*% em2$par[-2, ]) * pstr_mat)
  Lhat <- duse2 %>% select(msno, Month) %>% mutate(L_hat = L) %>% group_by(msno, Month) %>% 
    summarise(L_hat = sum(L_hat), .groups = "drop") %>% left_join(mu_tib, by = "msno")
  # Estimate subscription equation.
  sub2 <-  dsub2 %>% left_join(Lhat, by = c("msno", "Month")) %>% 
    mutate(
      mustar_hat = resid(lm(mu_hat ~ Age + Female, data = ., na.action = na.exclude))
    )
  # If single price, just run probit
  probit1 <- glm(S ~ I(log(L_hat) - log(price)) + Age + Female + mustar_hat,
                 data = sub2, family = binomial(link = "probit"))
  sub_para <- coefficients(probit1)
  # return all paramters
  c(as.vector(em2$par), sub_para)
}
# Uncomment to do bootstrap
boot2 <- list()
B <- 5 # 5 is used for illustration; Used 100 in the actual estimation
B <- 100
pb <- progress_bar$new(total = B)
for (b in 1 : B) {
  pb$tick()
  users <- sample(unique(pull(data_small, msno)), replace = TRUE, 300)
  boot2[[b]] <- estimate_leisure2(users)[1:12]
}
se_usage2 <- matrix(
  apply(
    matrix(unlist(boot2), nr = length(boot2[[1]]), nc = B),
    1,
    sd
  ), nc = 2)

# Estimate using actual data #
em2 <- em_trnormal_empirical_type_slopes(
  Formula(Q ~ Holiday + WEEKEND + RH2M + PRECTOT | Holiday + WEEKEND),
  data = data_small, id = "msno", K = 2
)
# Estimates of mu
mu_tib <- tibble(
  msno = unique(data_small$msno),
  mu_hat = drop(em2$pstr %*% em2$par["cnst", ])
)
# Estimate the expected monthly leisure
# posterior matrix---same dimension as the raw useage data (including days without usage or usage = 0)
pstr_mat <- duse2 %>% select(msno) %>% left_join(
  as_tibble(em2$pstr) %>% mutate(msno = unique(data_small$msno)),
  by = "msno"
) %>% select(-msno) %>% as.matrix()
form1 <- formula(Q ~ Holiday + WEEKEND + RH2M + PRECTOT)
x.design <- model.matrix(update(form1, NULL ~ .), duse2)
L <- rowSums((x.design %*% em2$par[-2, ]) * pstr_mat)
Lhat <- duse2 %>% select(msno, Month) %>% mutate(L_hat = L) %>% group_by(msno, Month) %>% 
  summarise(L_hat = sum(L_hat), .groups = "drop") %>% left_join(mu_tib, by = "msno")
# Estimate subscription equation.
sub2 <-  dsub2 %>% left_join(Lhat, by = c("msno", "Month")) %>% 
  mutate(
    mustar_hat = resid(lm(mu_hat ~ Age + Female, data = ., na.action = na.exclude))
  )
# If single price, just run probit
probit1 <- glm(S ~ I(log(L_hat) - log(price)) + Age + Female + mustar_hat,
               data = sub2, family = binomial(link = "probit"))
# report estimates, t values etc.
tvalue2 <- em2$par / se_usage2
dimnames(se_usage2) <- list(rownames(em2$par), colnames(em2$par))
round(em2$par, 4)
round(se_usage2, 4)
parahat <- tibble(
  parameters = names(boot2[[1]]),
  estimate = apply(matrix(unlist(boot2), nc = B), 1, mean),
  se = apply(matrix(unlist(boot2), nc = B), 1, sd),
  tv = estimate / se
)
parahat
mustar_hat_vec <- sapply(boot2, function(x) tail(x, 1))
summary(mustar_hat_vec)
qmu <- quantile(mustar_hat_vec, probs = seq(0, 1, by = 0.01))
sd(mustar_hat_vec[mustar_hat_vec > qmu[1] & mustar_hat_vec < qmu[101]])
sub_para <- coefficients(probit1)
sigmau <- 1 / sub_para["I(log(L_hat) - log(price))"]
names(sigmau) <- "sigmau"
beta <- sigmau * sub_para[c("(Intercept)", "Age", "I(Age^2)", "Female")]
sigmaumu <- sigmau * sub_para["mustar_hat"]
names(sigmaumu) <- "sigmaumu"

print(paste("Table 2 Usage Parameters:"))
testimate = t(t(c(em2$par[1:4,1],em2$par[1:4,2],em2$par[5:6,1])))
tsd = t(t(c(se_usage2[1:4,1],se_usage2[1:4,2],se_usage2[5:6,1])))
estimate_gamma = round(cbind(testimate,tsd),4)
colnames(estimate_gamma)=c("estimate","se")
estimate_gamma
print(paste("Table 2 Subscription Parameters:"))
summary(probit1)


# price elasticity (use the formula after Theorem 3) and its std err
epricef <- function(id) {
  # Omit age squared
  # id is the row id of relevant data
  p0 <- predict(probit1)
  p1 <- p0[id]
  sub3 <- dplyr::slice(sub2, id)
  eprice <- - mean(dnorm(p1)) / sigmau / mean(sub3$S)
  names(eprice) <- "price_elasticity"
  g1 <- eprice * sigmau + mean(dnorm(p1) * (- p1) * (- log(sub3$price) + log(sub3$L_hat))) / sigmau / mean(sub2$S)
  temp <- dnorm(p1) * (- p1)
  temp1 <- matrix(rep(temp, 4), nc = 4)
  temp2 <- sub3 %>% select(Age, Female, mustar_hat) %>% data.matrix()
  temp2 <- cbind(1, temp2)
  temp3 <- apply(temp1 * temp2, 2, mean)
  g2 <- temp3 / mean(sub3$S) / sigmau
  G <- t(c(g2[1], g1, g2[-1]))
  eprice_se <- sqrt(G %*% vcov(probit1) %*% t(G))
  c(price_elasticity = eprice, se = eprice_se)
}
# All users
eprice_all <- epricef(id = seq_len(nrow(sub2)))
male.id <- which(sub2$Female == 0)
eprice_male <- epricef(male.id)
female.id <- which(sub2$Female == 1)
eprice_female <- epricef(female.id)
age.group22 <- which(sub2$Age <= 22)
age.group23_30 <- which(sub2$Age > 22 & sub2$Age <= 30)
age.group30 <- which(sub2$Age > 30)
eprice_age22 <- epricef(age.group22)
eprice_age23_30 <- epricef(age.group23_30)
eprice_age30 <- epricef(age.group30)
eprice_mat <- rbind(eprice_all, eprice_male, eprice_female, eprice_age22, eprice_age23_30, eprice_age30)
surround <- function(x, digits) sprintf(paste0("(%.", digits, "f)"), round(x, digits))
eprice_tib <- tibble(
  Groups = c("All Subscribers", "Male", "Female", "Age $\\leq$ 22", "Age 23--30", "Age > 30"),
  "Price Elasticity" = round(eprice_mat[,1], 3),
  "Std Err" = surround(eprice_mat[,2], 3)
)

# WTP distribution
# The following lines are to plot WTP distribution.
sigmau_inv <- probit1$coefficients["I(log(L_hat) - log(price))"]
p1 <- predict(probit1) + log(149) * sigmau_inv
w <- c(100 : 1000)
cdf_w <- map_dbl(w, ~ mean(pnorm(log(.x) * sigmau_inv - p1)))
cdf_tib <- tibble(WTP = w, Prob = cdf_w)
p.149 <- round(cdf_tib %>% filter(WTP == 149) %>% pull(Prob), 3)
w.50 <- head(cdf_tib %>% mutate(temp = abs(Prob - 0.5)) %>% arrange(temp) %>% pull(WTP), 1)
ann1 <- data.frame(
  x = c(149, w.50),
  y = c(p.149, 0.50),
  label = c("Current Monthly Price $149", paste0("Median WTP for Monthly Plan $", w.50))
  )
gg_cdf_month <- ggplot(cdf_tib, aes(x = WTP, y = Prob)) + geom_line() +
  # Mark current price
  geom_segment(aes(x = 149, y = -Inf, xend = 149, yend = p.149), linetype = "dashed") +
  geom_segment(aes(x = -Inf, y = p.149, xend = 149, yend = p.149), linetype = "dashed") +
  # Mark median WTP
  geom_segment(aes(x = w.50, y = -Inf, xend = w.50, yend = 0.50), linetype = "dashed") +
  geom_segment(aes(x = -Inf, y = 0.50, xend = w.50, yend = 0.50), linetype = "dashed") +
  geom_text(data = ann1[1, ], aes(x = x, y = y, label = label), fontface = "bold", nudge_x = 200) +
  geom_text(data = ann1[2, ], aes(x = x, y = y, label = label), fontface = "bold", nudge_x = 250) +
  scale_x_continuous(
    name="WTP for Current Monthly Plan",
    breaks = c(149, w.50, 500, 750, 1000),
    limits = range(w)
    ) +
  scale_y_continuous(
    name="Prob",
    breaks = c(p.149, 0.25, 0.50, 0.75, 1),
    limits = c(0, 1)
    ) +
  theme_Publication()
# Uncomment to save plot
# ggpubr::ggexport(gg_cdf_month, filename = "CDF_WTP_Month_RR1.png")


# WTP for different groups
find_w50 <- function(p1) {
  cdf_w <- map_dbl(w, ~ mean(pnorm(log(.x) * sigmau_inv - p1)))
  cdf_tib <- tibble(WTP = w, Prob = cdf_w)
  p.149 <- round(cdf_tib %>% filter(WTP == 149) %>% pull(Prob), 3)
  w.50 <- head(cdf_tib %>% mutate(temp = abs(Prob - 0.5)) %>% arrange(temp) %>% pull(WTP), 1)
  w.50
}

p1_all <- dsub2 %>% mutate(p1 = p1) %>% pull(p1)
p1_female <- dsub2 %>% mutate(p1 = p1) %>% filter(Female == 1) %>% pull(p1)
p1_male <- dsub2 %>% mutate(p1 = p1) %>% filter(Female == 0) %>% pull(p1)
p1_age22 <- dsub2 %>% mutate(p1 = p1) %>% filter(Age <= 22) %>% pull(p1)
p1_age23 <- dsub2 %>% mutate(p1 = p1) %>% filter(between(Age, 23, 30)) %>% pull(p1)
p1_age31 <- dsub2 %>% mutate(p1 = p1) %>% filter(Age > 30) %>% pull(p1)
# Find median WTP for each group of consumers

print(paste("Table 4 WTP Estimates"))
find_w50(p1_all)
find_w50(p1_male)
find_w50(p1_female)
find_w50(p1_age22)
find_w50(p1_age23)
find_w50(p1_age31)

# Revenue maximizing monthly price
temp2 <- sub2 %>% select(Age, Female, mustar_hat) %>% data.matrix()
temp2 <- cbind(1, temp2)
betabar <- drop(temp2 %*% coefficients(probit1)[-2])
sub3 <- sub2 %>% mutate(betabar = betabar)
suinv <- coefficients(probit1)[2]
mr_month <- function(pmo, sub3) {
  # mr_month is the marginal revenue; pmo is the monthly cost
  sub4 <- sub3 %>% mutate(
    FW = pnorm(suinv * (log(pmo) - log(L_hat)) - betabar),
    fW = dnorm(suinv * (log(pmo) - log(L_hat)) - betabar)
  ) %>% group_by(msno) %>% 
    summarize(
      mr = sum(suinv^(-1) * (1 - FW)) - sum(fW),
      .groups = "drop"
    )
  mean(sub4$mr)
}
pmo <- uniroot(mr_month, lower = 149, upper = 500, sub3 = sub3)
pmo_male <- uniroot(mr_month, lower = 149, upper = 500, sub3 = filter(sub3, Female == 0))
pmo_female <- uniroot(mr_month, lower = 149, upper = 500, sub3 = filter(sub3, Female == 1))
pmo_age22 <- uniroot(mr_month, lower = 149, upper = 500, sub3 = filter(sub3, Age <= 22))
pmo_age23 <- uniroot(mr_month, lower = 149, upper = 500, sub3 = filter(sub3, between(Age, 23, 30)))
pmo_age30 <- uniroot(mr_month, lower = 149, upper = 500, sub3 = filter(sub3, Age > 30))

print(paste("Table 4 Estimates"))
eprice_tib %>% 
  mutate(
    RevenueMaxPrice = map_dbl(list(pmo, pmo_male, pmo_female, pmo_age22, pmo_age23, pmo_age30), ~ .x$root)
  )

# Robustness check---check the exogeneity of weather
# One: Remove precipitation
em3 <- em_trnormal_empirical_type_slopes(
  Formula(Q ~ Holiday + WEEKEND + RH2M | Holiday + WEEKEND),
  data = data_small,
  id = "msno", K = 2
)
# Estimates of mu
mu_tib <- tibble(
  msno = unique(data_small$msno),
  mu_hat = drop(em3$pstr %*% em3$par["cnst", ])
)
# Estimate the expected monthly leisure
# posterior matrix---same dimension as the raw useage data (including days without usage or usage = 0)
pstr_mat <- duse2 %>% select(msno) %>% left_join(
  as_tibble(em3$pstr) %>% mutate(msno = unique(data_small$msno)),
  by = "msno"
) %>% select(-msno) %>% as.matrix()
form1 <- formula(Q ~ Holiday + WEEKEND + RH2M)
x.design <- model.matrix(update(form1, NULL ~ .), duse2)
L <- rowSums((x.design %*% em3$par[-2, ]) * pstr_mat)
Lhat <- duse2 %>% select(msno, Month) %>% mutate(L_hat = L) %>% group_by(msno, Month) %>% 
  summarise(L_hat = sum(L_hat), .groups = "drop") %>% left_join(mu_tib, by = "msno")
# Estimate subscription equation.
sub2 <-  dsub2 %>% left_join(Lhat, by = c("msno", "Month")) %>% 
  mutate(
    mustar_hat = resid(lm(mu_hat ~ Age + Female, data = ., na.action = na.exclude))
  )
probit1 <- glm(S ~ I(log(L_hat) - log(price)) + Age + Female + mustar_hat,
               data = sub2, family = binomial(link = "probit"))
sub_para <- coefficients(probit1)
sigmau <- 1 / sub_para["I(log(L_hat) - log(price))"]
names(sigmau) <- "sigmau"
beta <- sigmau * sub_para[c("(Intercept)", "Age", "I(Age^2)", "Female")]
sigmaumu <- sigmau * sub_para["mustar_hat"]
names(sigmaumu) <- "sigmaumu"
eprice_all <- epricef(id = seq_len(nrow(sub2)))
eprice_male <- epricef(male.id)
eprice_female <- epricef(female.id)
eprice_age22 <- epricef(age.group22)
eprice_age23_30 <- epricef(age.group23_30)
eprice_age30 <- epricef(age.group30)
eprice_mat <- rbind(eprice_all, eprice_male, eprice_female, eprice_age22, eprice_age23_30, eprice_age30)
eprice_tib2 <- tibble(
  Groups = c("All Subscribers", "Male", "Female", "Age $\\leq$ 22", "Age 23--30", "Age > 30"),
  "Price Elasticity" = round(eprice_mat[,1], 3),
  "Std Err" = surround(eprice_mat[,2], 3)
)

# Two: Remove humid
em4 <- em_trnormal_empirical_type_slopes(
  Formula(Q ~ Holiday + WEEKEND + PRECTOT | Holiday + WEEKEND),
  data = data_small,
  id = "msno", K = 2
)
# Estimates of mu
mu_tib <- tibble(
  msno = unique(data_small$msno),
  mu_hat = drop(em4$pstr %*% em4$par["cnst", ])
)
# Estimate the expected monthly leisure
# posterior matrix---same dimension as the raw useage data (including days without usage or usage = 0)
pstr_mat <- duse2 %>% select(msno) %>% left_join(
  as_tibble(em4$pstr) %>% mutate(msno = unique(data_small$msno)),
  by = "msno"
) %>% select(-msno) %>% as.matrix()
form1 <- formula(Q ~ Holiday + WEEKEND + RH2M)
x.design <- model.matrix(update(form1, NULL ~ .), duse2)
L <- rowSums((x.design %*% em4$par[-2, ]) * pstr_mat)
Lhat <- duse2 %>% select(msno, Month) %>% mutate(L_hat = L) %>% group_by(msno, Month) %>% 
  summarise(L_hat = sum(L_hat), .groups = "drop") %>% left_join(mu_tib, by = "msno")
# Estimate subscription equation.
sub2 <-  dsub2 %>% left_join(Lhat, by = c("msno", "Month")) %>% 
  mutate(
    mustar_hat = resid(lm(mu_hat ~ Age + Female, data = ., na.action = na.exclude))
  )
probit1 <- glm(S ~ I(log(L_hat) - log(price)) + Age + Female + mustar_hat,
               data = sub2, family = binomial(link = "probit"))
sub_para <- coefficients(probit1)
sigmau <- 1 / sub_para["I(log(L_hat) - log(price))"]
names(sigmau) <- "sigmau"
beta <- sigmau * sub_para[c("(Intercept)", "Age", "I(Age^2)", "Female")]
sigmaumu <- sigmau * sub_para["mustar_hat"]
names(sigmaumu) <- "sigmaumu"
eprice_all <- epricef(id = seq_len(nrow(sub2)))
eprice_male <- epricef(male.id)
eprice_female <- epricef(female.id)
eprice_age22 <- epricef(age.group22)
eprice_age23_30 <- epricef(age.group23_30)
eprice_age30 <- epricef(age.group30)
eprice_mat <- rbind(eprice_all, eprice_male, eprice_female, eprice_age22, eprice_age23_30, eprice_age30)
eprice_tib3 <- tibble(
  Groups = c("All Subscribers", "Male", "Female", "Age $\\leq$ 22", "Age 23--30", "Age > 30"),
  "Price Elasticity" = round(eprice_mat[,1], 3),
  "Std Err" = surround(eprice_mat[,2], 3)
)


print(paste("Table 5 Estimates"))
eprice_tib # use both humidity and precipitation
eprice_tib2 # use only humidity 
eprice_tib3 # use only precipitation
